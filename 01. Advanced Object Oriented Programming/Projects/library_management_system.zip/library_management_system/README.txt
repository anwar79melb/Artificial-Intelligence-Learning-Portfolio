Library Management System
=========================

Requirements:
- Windows 10 or later
- Python 3.9+
- Tkinter (included with standard Python)

How to Run:
-----------

1. Ensure Python is installed
2. Unzip the project folder
3. Double-click:
       launch_library.bat
4. Login screen will appear

======================================
NOTE:
The launch_library.bat file was created by saving the following code as library_launch.bat file:
@echo off
cd /d D:\library_management_system
"C:\Users\anwar\anaconda3\python.exe" -m gui.app
 
This means my the path of my Python is "C:\Users\anwar\anaconda3\python.exe".

To run form shell:
1. Open POWERSHELL by pressing windows + R, type wt and enter. 
2. type cd "path-to-folder" and press enter to change directory (for me it was cd D/library_management_system
3. type & "path-to-python-installation" -m gui.app (for me the path was C:\Users\anwar\anaconda3\python.exe
======================================


Default Admin Account:
----------------------
Username: admin
Password: admin123

Members' account details:
-----------------------
Username: alice
Password: alice123

Username: bob
Password: bob123

Username: anaya
Password: anaya123

Username: jon
Password: jon123

Username: hui
Password: hui123



Data:
-----
- Persistent data stored in .dat files
- CSV exports generated automatically
- Logs stored in logs/system.log

Notes:
------
- Do NOT edit .dat files manually
- Logs are read-only by design


Process Borrows helps to help members borrow a book by the admin, whereas Manage Borrows helps the admin to process return of books 
and reassign borrow to members based on existing borrow history.