class Book:
    def __init__(self, book_id, title, author, category, isbn):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.category = category
        self.isbn = isbn
        self.copies = []
    
    def add_copy(self, book_id):
        self.copies.append(copy)
        book = self.get_book_by_id(book_id)
        copy = BookCopy(
            copy_id=str(uuid.uuid4()),
            book_id=book_id,
            status="AVAILABLE"
        )
        book.copies.append(copy)
        return copy





class BookCopy:
    def __init__(self, copy_id, book_id, status="AVAILABLE"):
        self.copy_id = copy_id
        self.book_id = book_id
        self.status = status

        # ✅ Reservation fields (ALWAYS present)
        self.reserved_for = None         # member_id
        self.reserved_until = None       # datetime






