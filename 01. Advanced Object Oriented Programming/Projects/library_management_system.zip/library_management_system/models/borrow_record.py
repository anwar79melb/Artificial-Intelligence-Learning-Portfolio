class BorrowRecord:
    def __init__(self, record_id, member_id, copy_id,
                 borrow_date, due_date,
                 return_date=None, fine_amount=0.0,
                 status="ACTIVE"):
        self.record_id = record_id
        self.member_id = member_id
        self.copy_id = copy_id
        self.borrow_date = borrow_date
        self.due_date = due_date
        self.return_date = return_date
        self.fine_amount = fine_amount
        self.status = status