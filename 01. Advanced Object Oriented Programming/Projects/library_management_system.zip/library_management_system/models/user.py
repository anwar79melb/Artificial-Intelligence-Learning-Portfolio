from abc import ABC, abstractmethod


from policies.borrowing_policy import (
    ParentBorrowingPolicy,
    ChildBorrowingPolicy,
    GeneralBorrowingPolicy,
    StaffBorrowingPolicy
)
from policies.fine_policy import (
    ParentFinePolicy,
    ChildFinePolicy,
    GeneralFinePolicy,
    StaffFinePolicy
)
from policies.suspension_policy import SuspensionPolicy

class User(ABC):
     def __init__(self, user_id, username, password_hash, full_name, active=True):
          self.user_id = user_id
          self.username = username
          self.password_hash = password_hash
          self.full_name = full_name
          self.active = active
          self.suspension_policy = SuspensionPolicy()
          
     def deactivate(self):
         self.active = False
     
     def activate(self):
         self.active = True
     
     @abstractmethod
     def get_role(self):
         pass



class Staff(User):
    
    def __init__(self, user_id, username, password_hash, full_name, role):
        super().__init__(user_id, username, password_hash, full_name)
        self.role = role
        self.borrowing_policy = StaffBorrowingPolicy()
        self.fine_policy = StaffFinePolicy()


    def get_role(self):
        return f"Staff:{self.role}"



class Member(User):
    def __init__(self, user_id, username, password_hash, full_name,
                 borrowing_policy, fine_policy):
        super().__init__(user_id, username, password_hash, full_name)
        self.borrowing_policy = borrowing_policy
        self.fine_policy = fine_policy

    def get_role(self):
        return "Member"



class ParentMember(Member):
    def get_role(self):
        return "Member:Parent"


class ChildMember(Member):
    def get_role(self):
        return "Member:Child"


class GeneralMember(Member):
    def get_role(self):
        return "Member:General"

