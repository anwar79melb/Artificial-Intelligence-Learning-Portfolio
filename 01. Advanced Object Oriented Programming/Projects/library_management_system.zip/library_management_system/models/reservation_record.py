from datetime import datetime


from datetime import datetime

class ReservationRecord:
    def __init__(
        self,
        reservation_id,
        book_id,
        member_id,
        status="ACTIVE",
        reserved_at=None,
        expires_at=None,
        copy_id=None
    ):
        self.reservation_id = reservation_id
        self.book_id = book_id
        self.member_id = member_id
        self.status = status

        self.reserved_at = reserved_at
        self.expires_at = expires_at
        self.copy_id = copy_id

        self.created_at = datetime.now()