
from models.user import GeneralMember, ChildMember, ParentMember
from policies.borrowing_policy import (
    GeneralBorrowingPolicy,
    ChildBorrowingPolicy,
    ParentBorrowingPolicy
)

from policies.fine_policy import (
    GeneralFinePolicy,
    ChildFinePolicy,
    ParentFinePolicy
)

from utils.hashing import hash_password
from utils.exceptions import ValidationError
import uuid



class MemberService:
    """
    Business logic for managing members and staff users.
    """

    def __init__(self, members: list, borrow_records: list):
        self.members = members
        self.borrow_records = borrow_records


    def create_staff(self, username, password, full_name, role):
        self._ensure_username_unique(username)

        user = Staff(
            user_id=str(uuid.uuid4()),
            username=username,
            password_hash=hash_password(password),
            full_name=full_name,
            role=role
        )

        self.members.append(user)
        return user


    
    def create_member(self, member_type, username, password, full_name):
        # Check for duplicate username
        for user in self.members:
            if user.username == username:
                raise ValidationError("Username already exists.")

        user_id = str(uuid.uuid4())
        password_hash = hash_password(password)
        member_type = member_type.lower()

        if member_type == "general":
            borrowing_policy = GeneralBorrowingPolicy()
            fine_policy = GeneralFinePolicy()
            member = GeneralMember(
                user_id, username, password_hash, full_name,
                borrowing_policy, fine_policy
            )

        elif member_type == "child":
            borrowing_policy = ChildBorrowingPolicy()
            fine_policy = ChildFinePolicy()
            member = ChildMember(
                user_id, username, password_hash, full_name,
                borrowing_policy, fine_policy
            )

        elif member_type == "parent":
            borrowing_policy = ParentBorrowingPolicy()
            fine_policy = ParentFinePolicy()
            member = ParentMember(
                user_id, username, password_hash, full_name,
                borrowing_policy, fine_policy
            )

        else:
            raise ValidationError("Invalid member type.")

        self.members.append(member)
        return member



    def delete_member(self, member_id, borrow_records, reservations):
        member = self.get_member_by_id(member_id)

        # Check for active borrows
        for r in borrow_records:
            if r.member_id == member_id and r.status == "ACTIVE":
                raise BusinessRuleError(
                    "Cannot delete member: member has active borrowed items."
                )

        # Check for active reservations
        for r in reservations:
            if r.member_id == member_id and r.status == "ACTIVE":
                raise BusinessRuleError(
                    "Cannot delete member: member has active reservations."
                )

        self.members.remove(member)


    def get_user_by_username(self, username):
        for user in self.members:
            if user.username == username:
                return user
        raise ValidationError("User not found.")
    
    def get_user_by_id(self, user_id):
        for user in self.members:
            if user.user_id == user_id:
                return user
        raise ValidationError("User not found.")
    
    def _ensure_username_unique(self, username):
        for user in self.members:
            if user.username == username:
                raise ValidationError("Username already exists.")


    
    def get_member_by_id(self, member_id):
        for member in self.members:
            if member.user_id == member_id:
                return member
        raise ValueError("Member not found")


    def suspend_user(self, user_id):
        user = self.get_user_by_id(user_id)
        user.deactivate()

    def activate_user(self, user_id):
        user = self.get_user_by_id(user_id)
        user.activate()

    def count_active_borrows(self, member_id):
        count = 0
        for record in self.borrow_records:
            if record.member_id == member_id and record.status == "ACTIVE":
                count += 1
        return count
    
    def can_member_borrow(self, member_id):
        member = self.get_user_by_id(member_id)

        if not member.active:
            raise BusinessRuleError("Account is suspended.")

        current_borrows = self.count_active_borrows(member_id)
        return member.borrowing_policy.can_borrow(current_borrows)
    
    def delete_user(self, user_id):
        user = self.get_user_by_id(user_id)

        for record in self.borrow_records:
            if record.member_id == user_id and record.status == "ACTIVE":
                raise BusinessRuleError(
                    "Cannot delete user with active borrow records."
                )

        self.members.remove(user)

    