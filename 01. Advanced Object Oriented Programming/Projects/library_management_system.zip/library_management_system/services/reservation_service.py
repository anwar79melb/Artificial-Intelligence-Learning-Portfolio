
from utils.logger import log_event
from models.reservation_record import ReservationRecord
from utils.exceptions import ValidationError, BusinessRuleError
import uuid
from datetime import datetime, timedelta


class ReservationService:
    """
    Business logic for managing book reservations (FIFO).
    """

    def __init__(self, reservations: list, book_service, member_service):
        self.reservations = reservations
        self.book_service = book_service
        self.member_service = member_service

    def create_reservation(self, member_id, book_id):
        # Ensure book exists
        book = self.book_service.get_book_by_id(book_id)

        # Ensure book is currently unavailable
        if self.book_service.is_book_available(book_id):
            raise BusinessRuleError("Book is currently available; reservation not allowed.")

        member = self.member_service.get_user_by_id(member_id)

        # Check policy: can this member reserve?
        if not member.borrowing_policy.can_reserve():
            raise BusinessRuleError("This member type cannot place reservations.")

        # Prevent duplicate active reservation
        for r in self.reservations:
            if (
                r.book_id == book_id
                and r.member_id == member_id
                and r.status == "ACTIVE"
            ):
                raise BusinessRuleError(
                    "You already have an active reservation for this book."
                )

        # ✅ CORRECT constructor call (NO reservation_date)
        reservation = ReservationRecord(
            reservation_id=str(uuid.uuid4()),
            book_id=book_id,
            member_id=member_id,
            status="ACTIVE"
        )

        self.reservations.append(reservation)

        log_event(
            f"Reservation created: member_id={member_id}, "
            f"book_id={book_id}, reservation_id={reservation.reservation_id}"
        )

        return reservation
        
    
    
    def has_active_reservation_for_book(self, book_id):
        return any(
            r.book_id == book_id and r.status in ("ACTIVE", "WAITING")
            for r in self.reservations
        )


    
    def cancel_reservation(self, reservation_id, member_id):
        reservation = self.get_reservation_by_id(reservation_id)

        if reservation.member_id != member_id:
            raise BusinessRuleError("Cannot cancel another member's reservation.")

        if reservation.status != "ACTIVE":
            raise BusinessRuleError("Only active reservations can be cancelled.")

        reservation.status = "CANCELLED"
        
        log_event(
            f"Reservation cancelled: reservation_id={reservation.reservation_id}, member_id={member_id}"
        )


    def get_reservation_by_id(self, reservation_id):
        for reservation in self.reservations:
            if reservation.reservation_id == reservation_id:
                return reservation

        raise ValidationError("Reservation not found.")
    

    
    def get_active_reservations_by_book(self, book_id):
        return [
            r for r in self.reservations
            if r.book_id == book_id and r.status in ("ACTIVE", "WAITING")
        ]



    def get_active_reservation_for_book(self, book_id):
        for r in self.reservations:
            if r.book_id == book_id and r.status in ("ACTIVE", "WAITING"):
                return r
        return self.get_active_reservations_by_book (book_id)


    def get_blocking_reservation_for_book(self, book_id):
        for r in self.reservations:
            if r.book_id == book_id and r.status in ("ACTIVE", "WAITING"):
                return r
        return None

    
    
    def get_next_reservation_for_book(self, book_id):
        active = [
            r for r in self.reservations
            if r.book_id == book_id and r.status == "ACTIVE"
        ]
        return active[0] if active else None


    def place_copy_on_hold(self, reservation, copy):
        reservation.status = "WAITING"
        reservation.reserved_at = datetime.now()
        reservation.expires_at = reservation.reserved_at + timedelta(days=3)
        reservation.copy_id = copy.copy_id

        copy.status = "RESERVED"
        copy.reserved_for = reservation.member_id

    def release_expired_holds(self):
        now = datetime.now()
        for r in self.reservations:
            if r.status == "WAITING" and r.expires_at <= now:
                copy = self.book_service.get_copy_by_id(r.copy_id)
                copy.status = "AVAILABLE"
                copy.reserved_for = None
                r.status = "EXPIRED"


    
    def mark_fulfilled(self, reservation_id):
        reservation = self.get_reservation_by_id(reservation_id)

        if reservation.status != "ACTIVE":
            raise BusinessRuleError("Only active reservations can be fulfilled.")

        reservation.status = "FULFILLED"

        
        log_event(
            f"Reservation fulfilled: reservation_id={reservation.reservation_id}, book_id={reservation.book_id}"
        )

    
    def cleanup_expired_reservations(self):
        now = datetime.now()
        for r in self.reservations:
            if r.status == "WAITING" and r.expires_at < now:
                r.status = "EXPIRED"
                copy = self.book_service.get_copy_by_id(r.copy_id)
                copy.status = "AVAILABLE"
                copy.reserved_for = None


    def remove_inactive_reservations(self):
        self.reservations[:] = [
            r for r in self.reservations
            if r.status == "ACTIVE"
        ]

    