from utils.logger import log_event
from models.borrow_record import BorrowRecord
from datetime import datetime, timedelta
from utils.exceptions import BusinessRuleError
import uuid


class BorrowService:
    """
    Handles borrowing operations for members.
    """

    MAX_LOAN_DAYS = 14

    def __init__(self, borrow_records, book_service, member_service, reservation_service):
        self.borrow_records = borrow_records
        self.book_service = book_service
        self.member_service = member_service
        self.reservation_service = reservation_service

    # ==================================================
    # Public API used by GUI
    # ==================================================


    def borrow(self, member_id, book_id):
        member = self.member_service.get_member_by_id(member_id)

        if not member.active:
                raise BusinessRuleError("Account is suspended.")

            # --------------------------------------------------
            # ✅ BOOK-LEVEL reservation lock (FINAL AUTHORITY)
            # --------------------------------------------------
        reservation = self.reservation_service.get_blocking_reservation_for_book(book_id)


        # --------------------------------------------------
        # ✅ Enforce maximum active loan policy (CRITICAL)
        # --------------------------------------------------
        active_loans = self._count_active_loans(member_id)
        max_allowed = member.borrowing_policy.max_books_allowed()

        if active_loans >= max_allowed:
            raise BusinessRuleError(
                f"Borrowing limit reached: "
                f"{active_loans}/{max_allowed} active loans."
            )


        if reservation and reservation.member_id != member_id:
                raise BusinessRuleError(
                    "This book is reserved by another member."
                )

            # --------------------------------------------------
            # ✅ Select copy only AFTER reservation check
            # --------------------------------------------------
        copy = self.book_service.get_available_copy(book_id)

        if not copy:
            raise BusinessRuleError("No available copies for this book.")


        # ✅ Create borrow record FIRST
        borrow_date = datetime.now()
        due_date = borrow_date + member.borrowing_policy.borrowing_duration()

        record = BorrowRecord(
            record_id=str(uuid.uuid4()),
            member_id=member_id,
            copy_id=copy.copy_id,
            borrow_date=borrow_date,
            due_date=due_date,
            status="ACTIVE"
        )

        self.borrow_records.append(record)

        # ✅ Update copy state after record exists
        copy.status = "BORROWED"

        # ✅ Fulfill reservation
        if reservation and reservation.member_id == member_id:
            reservation.status = "FULFILLED"

        return record
    
    # ==================================================
    # Return handling
    # ==================================================

    
    
    def _count_active_loans(self, member_id):
        return sum(
            1 for r in self.borrow_records
            if r.member_id == member_id and r.status == "ACTIVE"
        )

    
    
    def get_available_copy(self, book_id):
        book = self.get_book_by_id(book_id)
        for copy in book.copies:
            if copy.status == "AVAILABLE":
                return copy
        return None

    

    def return_book(self, record_id, condition):
        # Find active borrow record
        record = None
        for r in self.borrow_records:
            if r.record_id == record_id and r.status == "ACTIVE":
                record = r
                break

        if not record:
            raise BusinessRuleError("Active borrow record not found.")

        # Get the copy
        copy = self.book_service.get_copy_by_id(record.copy_id)

        # Close borrow record
        record.return_date = datetime.now()
        record.status = "RETURNED"

        # Reset copy state first
        copy.status = "AVAILABLE"

        # --------------------------------------------------
        # ✅ FIX: obtain book correctly
        # --------------------------------------------------
        book = self.book_service.get_book_by_copy_id(copy.copy_id)

        # Check for reservation on this book
        reservation = self.reservation_service.get_blocking_reservation_for_book(
            book.book_id
        )

        if reservation:
            copy.status = "RESERVED"
            copy.reserved_for = reservation.member_id
            copy.reserved_until = datetime.now() + timedelta(days=3)

            reservation.status = "WAITING"
            reservation.copy_id = copy.copy_id
            reservation.reserved_at = datetime.now()
            reservation.expires_at = copy.reserved_until

        # --------------------------------------------------
        # Apply penalties
        # --------------------------------------------------
        if condition == "GOOD":
            self._apply_overdue_fine(record)
        elif condition == "DAMAGED":
            copy.status = "DAMAGED"
            record.fine_amount = record.member.fine_policy.damaged_penalty()
        elif condition == "LOST":
            copy.status = "LOST"
            record.fine_amount = record.member.fine_policy.lost_penalty()
        else:
            raise BusinessRuleError("Invalid return condition.")

        return record

    # ==================================================
    # Internal helpers
    # ==================================================

    def _get_record_by_id(self, record_id):
        for record in self.borrow_records:
            if record.record_id == record_id:
                return record
        raise BusinessRuleError("Borrow record not found.")

    def _apply_overdue_fine(self, record):
        if record.return_date <= record.due_date:
            record.fine_amount = 0.0
            return

        overdue_days = (record.return_date - record.due_date).days

        # ✅ Fine calculation (role-based)
        record.fine_amount = record.member.fine_policy.calculate_overdue_fine(overdue_days)

        # ✅ Suspension evaluation
        status = record.member.suspension_policy.evaluate(overdue_days)

        if status == "CATEGORY_1":
            # Reduce borrowing capacity and revoke reservation rights
            record.member.borrowing_policy.max_books_allowed = lambda: 2
            record.member.borrowing_policy.can_reserve = lambda: False

        elif status == "SUSPENDED":
            record.member.active = False
