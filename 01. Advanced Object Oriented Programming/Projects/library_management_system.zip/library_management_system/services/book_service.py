from utils.logger import log_event
from models.book import Book, BookCopy
from utils.exceptions import ValidationError, BusinessRuleError
import uuid


class BookService:
    """
    Service responsible for managing books and book copies.
    Contains business logic related to the library catalogue.
    """

    def __init__(self, books: list):
        """
        :param books: The in-memory list of Book objects
        """
        self.books = books

    # ----------------------
    # Book management
    # ----------------------

    def add_book(self, title, author, category, isbn):
        """
        Add a new book title to the library.
        ISBN must be unique.
        """
        for book in self.books:
            if book.isbn == isbn:
                raise ValidationError("A book with this ISBN already exists.")

        book_id = str(uuid.uuid4())
        new_book = Book(book_id, title, author, category, isbn)
        self.books.append(new_book)
        
        
        log_event(
            f"Book added: book_id={new_book.book_id}, title='{new_book.title}', author='{new_book.author}'"
        )

        return new_book

    def get_book_by_id(self, book_id):
        """
        Retrieve a book by its ID.
        """
        for book in self.books:
            if book.book_id == book_id:
                return book
        raise ValidationError("Book not found.")

    
    # ----------------------
    # Book copy management
    # ----------------------

    
    def add_copy(self, book_id):
        book = self.get_book_by_id(book_id)

        copy = BookCopy(
            copy_id=str(uuid.uuid4()),
            book_id=book_id,
            status="AVAILABLE"
        )

        book.copies.append(copy)
        
        log_event(
            f"Copy added: copy_id={copy.copy_id}, book_id={book_id}"
        )

        return copy


    def get_copy_by_id(self, copy_id):
        """
        Find a book copy by ID.
        """
        for book in self.books:
            for copy in book.copies:
                if copy.copy_id == copy_id:
                    return copy
        raise ValidationError("Book copy not found.")
    
    
    def get_book_by_copy_id(self, copy_id):
        for book in self.books:
            for copy in book.copies:
                if copy.copy_id == copy_id:
                    return book
        raise ValueError(f"Book not found for copy ID: {copy_id}")



    
    def remove_copy(self, copy_id):
        """
        Remove a book copy if it is available.
        """
        copy = self.get_copy_by_id(copy_id)

        if copy.status != "AVAILABLE":
            raise BusinessRuleError(
                "Only available copies can be deleted."
            )

        book = self.get_book_by_id(copy.book_id)
        book.copies.remove(copy)

        log_event(
            f"Copy deleted: copy_id={copy.copy_id}, book_id={book.book_id}"
        )



    def delete_book(self, book_id, borrow_records):
        book = self.get_book_by_id(book_id)

        # Check active borrows
        for record in borrow_records:
            if record.status == "ACTIVE":
                copy = self.get_copy_by_id(record.copy_id)
                if copy.book_id == book_id:
                    raise BusinessRuleError(
                        "Cannot delete book: one or more copies are currently borrowed."
                    )

        self.books.remove(book)



    # ----------------------
    # Availability & search
    # ----------------------

    def is_book_available(self, book_id):
        """
        Check if at least one copy of the book is available.
        """
        book = self.get_book_by_id(book_id)
        return any(copy.status == "AVAILABLE" for copy in book.copies)

    def get_available_copy(self, book_id):
        """
        Return the first available copy of a book.
        """
        book = self.get_book_by_id(book_id)
        for copy in book.copies:
            if copy.status == "AVAILABLE":
                return copy
        return None