
import sys
import os

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from core.library_system import LibrarySystem
from utils.hashing import hash_password

def run_tests():
    system = LibrarySystem()

    print("✅ System initialised")

    # --------------------
    # Ensure staff exists
    # --------------------
    if not system.members:
        staff = system.member_service.create_staff(
            username="admin",
            password="admin123",
            full_name="Library Admin",
            role="Manager"
        )
        system.save_all()
        print("✅ Staff created")

    staff = system.member_service.get_user_by_username("admin")
    system.current_user = staff

    # --------------------
    # Add book and copy
    # --------------------
    book = system.book_service.add_book(
        "Test Book",
        "Test Author",
        "Test Category",
        "ISBN-TEST-001"
    )
    system.book_service.add_copy(book.book_id)
    system.save_all()
    print("✅ Book and copy added")

    # --------------------
    # Create member
    # --------------------
    member = system.member_service.create_member(
        member_type="general",
        username="alice",
        password="password",
        full_name="Alice Smith"
    )
    system.save_all()
    print("✅ Member created")

    # --------------------
    # Borrow book
    # --------------------
    record = system.borrow_service.borrow_book(
        member.user_id,
        book.book_id
    )
    system.save_all()
    print("✅ Book borrowed")

    # --------------------
    # Return book
    # --------------------
    record = system.borrow_service.return_book(
        record.borrow_id,
        condition="GOOD"
    )
    system.save_all()
    print(f"✅ Book returned | Fine: ${record.fine_amount:.2f}")

    print("\n🎉 ALL TESTS COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    run_tests()
