@echo off
cd /d D:\library_management_system
"C:\Users\anwar\anaconda3\python.exe" -m gui.app
