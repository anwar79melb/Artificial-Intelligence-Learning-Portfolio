class SuspensionPolicy:
    """
    Evaluates member suspension status based on overdue duration.
    """

    def evaluate(self, overdue_days: int) -> str:
        if overdue_days >= 56:  # 8 weeks
            return "SUSPENDED"
        elif overdue_days >= 28:  # 4 weeks
            return "CATEGORY_1"
        return "ACTIVE"
