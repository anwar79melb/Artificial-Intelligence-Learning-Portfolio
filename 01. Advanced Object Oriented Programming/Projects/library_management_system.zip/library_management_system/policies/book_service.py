from models.book import Book, BookCopy
from utils.exceptions import ValidationError, BusinessRuleError
import uuid


class BookService:
    """
    Business logic for managing books and copies.
    """

    def __init__(self, books: list):
        self.books = books


    def add_book(self, title, author, category, isbn):
        # Prevent duplicate ISBNs
        for book in self.books:
            if book.isbn == isbn:
                raise ValidationError("Book with this ISBN already exists.")

        book_id = str(uuid.uuid4())
        new_book = Book(book_id, title, author, category, isbn)
        self.books.append(new_book)
        return new_book


    def update_book(self, book_id, title=None, author=None, category=None):
        book = self.get_book_by_id(book_id)

        if title:
            book.title = title
        if author:
            book.author = author
        if category:
            book.category = category

        return book


    def delete_book(self, book_id):
        book = self.get_book_by_id(book_id)

        for copy in book.copies:
            if copy.status != "AVAILABLE":
                raise BusinessRuleError(
                    "Cannot delete book with borrowed or reserved copies."
                )

        self.books.remove(book)


    def add_copy(self, book_id):
        book = self.get_book_by_id(book_id)

        copy_id = str(uuid.uuid4())
        new_copy = BookCopy(copy_id, book_id)
        book.add_copy(new_copy)

        return new_copy


    def is_book_available(self, book_id):
        book = self.get_book_by_id(book_id)
        return any(copy.status == "AVAILABLE" for copy in book.copies)


    def get_available_copy(self, book_id):
        book = self.get_book_by_id(book_id)

        for copy in book.copies:
            if copy.status == "AVAILABLE":
                return copy

        return None


    def search_by_title(self, keyword):
        return [
            book for book in self.books
            if keyword.lower() in book.title.lower()
        ]


    def search_by_author(self, keyword):
        return [
            book for book in self.books
            if keyword.lower() in book.author.lower()
        ]



    def filter_by_category(self, category):
        return [
            book for book in self.books
            if book.category.lower() == category.lower()
        ]


    def get_book_by_id(self, book_id):
        for book in self.books:
            if book.book_id == book_id:
                return book

        raise ValidationError("Book not found.")


