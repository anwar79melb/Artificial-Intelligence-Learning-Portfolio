from abc import ABC, abstractmethod
from datetime import timedelta


class BorrowingPolicy(ABC):
    """
    Strategy interface for borrowing rules.
    """

    @abstractmethod
    def max_books_allowed(self) -> int:
        pass

    @abstractmethod
    def borrowing_duration(self) -> timedelta:
        pass

    @abstractmethod
    def can_borrow(self, current_borrowed: int) -> bool:
        pass

    @abstractmethod
    def can_reserve(self) -> bool:
        pass


class ParentBorrowingPolicy(BorrowingPolicy):
    def max_books_allowed(self) -> int:
        return 5

    def borrowing_duration(self) -> timedelta:
        return timedelta(days=14)

    def can_borrow(self, current_borrowed: int) -> bool:
        return current_borrowed < self.max_books_allowed()

    def can_reserve(self) -> bool:
        return True



class ChildBorrowingPolicy(BorrowingPolicy):
    def max_books_allowed(self) -> int:
        return 2

    def borrowing_duration(self) -> timedelta:
        return timedelta(days=7)

    def can_borrow(self, current_borrowed: int) -> bool:
        return current_borrowed < self.max_books_allowed()

    def can_reserve(self) -> bool:
        return False



class GeneralBorrowingPolicy(BorrowingPolicy):
    def max_books_allowed(self) -> int:
        return 3

    def borrowing_duration(self) -> timedelta:
        return timedelta(days=14)

    def can_borrow(self, current_borrowed: int) -> bool:
        return current_borrowed < self.max_books_allowed()

    def can_reserve(self) -> bool:
        return True


class StaffBorrowingPolicy(BorrowingPolicy):
    def max_books_allowed(self) -> int:
        return 10

    def borrowing_duration(self) -> timedelta:
        return timedelta(days=28)

    def can_borrow(self, current_borrowed: int) -> bool:
        return current_borrowed < self.max_books_allowed()

    def can_reserve(self) -> bool:
        return True