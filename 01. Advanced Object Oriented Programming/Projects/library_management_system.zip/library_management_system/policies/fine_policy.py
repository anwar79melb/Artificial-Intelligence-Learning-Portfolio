from abc import ABC, abstractmethod


class FinePolicy(ABC):
    """
    Strategy interface for fine and penalty calculation.
    """

    @abstractmethod
    def calculate_overdue_fine(self, overdue_days: int) -> float:
        pass

    @abstractmethod
    def damaged_penalty(self) -> float:
        pass

    @abstractmethod
    def lost_penalty(self) -> float:
        pass


class StandardFinePolicy(FinePolicy):

    def calculate_overdue_fine(self, days_overdue):
        return days_overdue * 0.5

    def damaged_penalty(self):
        return 10.0

    def lost_penalty(self):
        return 30.0


class ParentFinePolicy(FinePolicy):
    def calculate_overdue_fine(self, overdue_days: int) -> float:
        return overdue_days * 0.50  # cents per day

    def damaged_penalty(self) -> float:
        return 10.00

    def lost_penalty(self) -> float:
        return 30.00


class ChildFinePolicy(FinePolicy):
    def calculate_overdue_fine(self, overdue_days: int) -> float:
        return overdue_days * 0.20

    def damaged_penalty(self) -> float:
        return 5.00

    def lost_penalty(self) -> float:
        return 15.00


class GeneralFinePolicy(FinePolicy):
    def calculate_overdue_fine(self, overdue_days: int) -> float:
        return overdue_days * 1.00

    def damaged_penalty(self) -> float:
        return 15.00

    def lost_penalty(self) -> float:
        return 40.00

class StaffFinePolicy(FinePolicy):
    def calculate_overdue_fine(self, overdue_days: int) -> float:
        if overdue_days <= 0:
            return 0.0
        # $5 per week (rounded up)
        weeks = (overdue_days + 6) // 7
        return weeks * 5.0

    def damaged_penalty(self) -> float:
        return 0.0  # staff not penalised for damage by default

    def lost_penalty(self) -> float:
        return 0.0