from core.library_system import LibrarySystem
from cli.menu import start_cli


def main():
    system = LibrarySystem()
    start_cli(system)


if __name__ == "__main__":
    main()
