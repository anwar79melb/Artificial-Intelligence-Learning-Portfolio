class LibraryError(Exception):
    """Base exception for the library system."""
    pass

class AuthenticationError(LibraryError):
    pass

class AuthorizationError(LibraryError):
    pass

class ValidationError(LibraryError):
    pass

class BusinessRuleError(LibraryError):
    pass

class PersistenceError(LibraryError):
    pass