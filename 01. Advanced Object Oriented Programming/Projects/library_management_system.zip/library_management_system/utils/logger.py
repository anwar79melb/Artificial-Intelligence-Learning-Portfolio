from datetime import datetime
import os


LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "system.log")


def log_event(event: str):
    """
    Append a timestamped event message to the system log.
    """
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {event}\n")