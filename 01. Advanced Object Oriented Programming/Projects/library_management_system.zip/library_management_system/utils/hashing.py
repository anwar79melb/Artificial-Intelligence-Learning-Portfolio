import hashlib

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    """
    Verify a plaintext password against a stored hash.
    """
    return hash_password(password) == hashed
