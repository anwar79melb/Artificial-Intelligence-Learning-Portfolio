from utils.exceptions import AuthenticationError


from utils.exceptions import AuthenticationError


def start_cli(system):
    while True:
        print("\n=== Community Library Management System ===")
        print("1. Login")
        print("2. Exit")

        choice = input("Select option: ").strip()

        if choice == "1":
            username = input("Username: ").strip()
            password = input("Password: ").strip()

            try:
                system.login(username, password)
                route_user(system)
            except AuthenticationError as e:
                print(f"Login failed: {e}")

        elif choice == "2":
            system.shutdown()
            print("Goodbye.")
            break
        else:
            print("Invalid option.")

def route_user(system):
    user = system.get_current_user()

    if system.is_staff():
        from cli.staff_menu import staff_menu
        staff_menu(system)
    else:
        from cli.member_menu import member_menu
        member_menu(system)

def main_menu(system):
    while True:
        print("\n=== Community Library System ===")
        print("1. Login")
        print("2. Exit")

        choice = input("Select an option: ")

        if choice == "1":
            login_flow(system)
        elif choice == "2":
            system.shutdown()
            print("Goodbye.")
            break
        else:
            print("Invalid option.")

def login_flow(system):
    username = input("Username: ")
    password = input("Password: ")

    try:
        system.login(username, password)
        route_by_role(system)
    except AuthenticationError as e:
        print(f"Login failed: {e}")


def route_by_role(system):
    user = system.get_current_user()

    if system.is_staff():
        from cli.staff_menu import staff_menu
        staff_menu(system)
    else:
        from cli.member_menu import member_menu
        member_menu(system)

    system.logout()


