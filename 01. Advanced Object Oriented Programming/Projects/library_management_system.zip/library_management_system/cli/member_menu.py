from utils.exceptions import BusinessRuleError, ValidationError


def member_menu(system):
    user = system.get_current_user()

    while True:
        print(f"\n--- Member Menu ({user.full_name}) ---")
        print("1. View Books")
        print("2. Borrow Book")
        print("3. Reserve Book")
        print("4. View My Reservations")
        print("5. Cancel Reservation")
        print("6. View Borrowing History")
        print("7. View Fines")
        print("8. Logout")

        choice = input("Select option: ").strip()

        # ----------------------------
        # View books
        # ----------------------------
        if choice == "1":
            for book in system.books:
                available = system.book_service.is_book_available(book.book_id)
                status = "Available" if available else "Unavailable"
                print(f"{book.book_id} | {book.title} | {status}")

        # ----------------------------
        # Borrow book
        # ----------------------------
        elif choice == "2":
            book_id = input("Enter Book ID: ").strip()
            try:
                system.borrow_service.borrow_book(user.user_id, book_id)
                system.save_all()
                print("✅ Book borrowed successfully.")
            except BusinessRuleError as e:
                print(f"❌ Cannot borrow: {e}")

        # ----------------------------
        # Reserve book
        # ----------------------------
        elif choice == "3":
            book_id = input("Enter Book ID to reserve: ").strip()
            try:
                system.reservation_service.create_reservation(
                    user.user_id, book_id
                )
                system.save_all()
                print("✅ Reservation placed.")
            except (BusinessRuleError, ValidationError) as e:
                print(f"❌ Cannot reserve: {e}")

        # ----------------------------
        # View reservations
        # ----------------------------
        elif choice == "4":
            reservations = [
                r for r in system.reservations
                if r.member_id == user.user_id and r.status == "ACTIVE"
            ]

            if not reservations:
                print("No active reservations.")
            else:
                print("\nYour Active Reservations:")
                for r in reservations:
                    print(
                        f"Reservation ID: {r.reservation_id} | "
                        f"Book ID: {r.book_id}"
                    )

        # ----------------------------
        # Cancel reservation
        # ----------------------------
        elif choice == "5":
            reservation_id = input(
                "Enter Reservation ID to cancel: "
            ).strip()

            try:
                system.reservation_service.cancel_reservation(
                    reservation_id,
                    user.user_id
                )
                system.save_all()
                print("✅ Reservation cancelled.")
            except (BusinessRuleError, ValidationError) as e:
                print(f"❌ Cannot cancel reservation: {e}")

        # ----------------------------
        # View borrowing history ✅ NEW
        # ----------------------------
        elif choice == "6":
            records = [
                r for r in system.borrow_records
                if r.member_id == user.user_id
            ]

            if not records:
                print("No borrowing history.")
            else:
                print("\n--- Borrowing History ---")
                for r in records:
                    print(
                        f"Borrow ID: {r.borrow_id}\n"
                        f"  Copy ID: {r.book_copy_id}\n"
                        f"  Borrowed: {r.borrow_date}\n"
                        f"  Due: {r.due_date}\n"
                        f"  Returned: {r.return_date}\n"
                        f"  Status: {r.status}\n"
                        f"  Fine: ${r.fine_amount:.2f}\n"
                    )

        # ----------------------------
        # View fines ✅ NEW
        # ----------------------------
        elif choice == "7":
            fines = [
                r.fine_amount for r in system.borrow_records
                if r.member_id == user.user_id and r.fine_amount > 0
            ]

            if not fines:
                print("No outstanding fines.")
            else:
                total = sum(fines)
                print("\n--- Fine Summary ---")
                for r in system.borrow_records:
                    if r.member_id == user.user_id and r.fine_amount > 0:
                        print(
                            f"Borrow ID: {r.borrow_id} | "
                            f"Fine: ${r.fine_amount:.2f}"
                        )
                print(f"\nTotal fines: ${total:.2f}")

        # ----------------------------
        # Logout
        # ----------------------------
        elif choice == "8":
            system.logout()
            break

        else:
            print("Invalid option.")