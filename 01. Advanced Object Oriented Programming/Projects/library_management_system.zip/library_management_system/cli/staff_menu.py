from utils.exceptions import BusinessRuleError, ValidationError
from datetime import datetime


def staff_menu(system):
    while True:
        print("\n--- Staff Menu ---")
        print("1. Add Book")
        print("2. Add Book Copy")
        print("3. View Books")
        print("4. Process Return")
        print("5. View Overdue Items")
        print("6. View Fines Summary")
        print("7. Logout")

        choice = input("Select option: ").strip()

        # ----------------------------
        # Add new book
        # ----------------------------
        if choice == "1":
            title = input("Title: ")
            author = input("Author: ")
            category = input("Category: ")
            isbn = input("ISBN: ")

            system.book_service.add_book(title, author, category, isbn)
            system.save_all()
            print("✅ Book added.")

        # ----------------------------
        # Add book copy
        # ----------------------------
        elif choice == "2":
            book_id = input("Book ID: ").strip()
            system.book_service.add_copy(book_id)
            system.save_all()
            print("✅ Copy added.")

        # ----------------------------
        # View books
        # ----------------------------
        elif choice == "3":
            for book in system.books:
                print(
                    f"{book.book_id} | {book.title} "
                    f"({len(book.copies)} copies)"
                )

        # ----------------------------
        # Process book return
        # ----------------------------
        elif choice == "4":
            borrow_id = input("Borrow Record ID: ").strip()
            print("Condition: GOOD / DAMAGED / LOST")
            condition = input("Condition: ").strip().upper()

            try:
                record = system.borrow_service.return_book(
                    borrow_id, condition
                )
                system.save_all()
                print(
                    f"✅ Book returned. Fine: ${record.fine_amount:.2f}"
                )
            except (BusinessRuleError, ValidationError) as e:
                print(f"❌ Error: {e}")

        # ----------------------------
        # View overdue items ✅ NEW
        # ----------------------------
        elif choice == "5":
            overdue_records = [
                r for r in system.borrow_records
                if r.status in ("ACTIVE", "OVERDUE")
                and datetime.now() > r.due_date
            ]

            if not overdue_records:
                print("✅ No overdue items.")
            else:
                print("\n--- Overdue Items ---")
                for r in overdue_records:
                    print(
                        f"Borrow ID: {r.borrow_id}\n"
                        f"  Member ID: {r.member_id}\n"
                        f"  Copy ID: {r.book_copy_id}\n"
                        f"  Due Date: {r.due_date}\n"
                        f"  Days Overdue: "
                        f"{(datetime.now() - r.due_date).days}\n"
                    )

        # ----------------------------
        # View fines summary ✅ NEW
        # ----------------------------
        elif choice == "6":
            fined_records = [
                r for r in system.borrow_records
                if r.fine_amount > 0
            ]

            if not fined_records:
                print("✅ No fines recorded.")
            else:
                total_fines = 0.0
                print("\n--- Fines Summary ---")

                for r in fined_records:
                    total_fines += r.fine_amount
                    print(
                        f"Borrow ID: {r.borrow_id} | "
                        f"Member ID: {r.member_id} | "
                        f"Fine: ${r.fine_amount:.2f}"
