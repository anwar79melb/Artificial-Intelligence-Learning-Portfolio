import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from policies.suspension_policy import SuspensionPolicy


# ===============================
# UI COLOR THEME
# ===============================
BACKGROUND = "#F4F6FA"
PRIMARY = "#2C3E50"
ACCENT = "#3498DB"
BUTTON_BG = "#ECF0F1"


class MemberView(tk.Frame):

    def __init__(self, master, system, on_logout):
        super().__init__(master)
        self.system = system
        self.on_logout = on_logout
        master.configure(bg=BACKGROUND)
        self.configure(bg=BACKGROUND)
        self.pack(fill=tk.BOTH, expand=True)

        
        self.configure(bg=BACKGROUND)

        tk.Label(self, text="Member Dashboard", font=("Arial", 18, "bold"), bg=BACKGROUND, fg=PRIMARY).pack(pady=20)


        tk.Button(self, text="My Messages", width=30, command=self.view_my_messages).pack(pady=5)

        tk.Button(self, text="Recommended for You", width=30, command=self.view_recommendations).pack(pady=5)


        tk.Button(self, text="Search Books", width=30, bg = BUTTON_BG, fg = PRIMARY, command=self.search_books).pack(pady=5)

        tk.Button(self, text="My Borrow Status", width=30, command=self.view_my_borrow_status).pack(pady=5)
        
        
        tk.Button(self, text="My Reservations", width=30, command=self.view_my_reservations).pack(pady=5)

        tk.Button(self, text="View My Borrowing Policy", width=30, command=self.view_borrowing_policy).pack(pady=5)

        tk.Button(self, text="Logout", width=30, command=self.logout).pack(pady=20)



    def view_my_messages(self):
        popup = tk.Toplevel(self)
        popup.title("My Messages")
        popup.geometry("600x400")

        text = tk.Text(
            popup,
            wrap="word",
            state="normal",
            padx=15,
            pady=15
        )
        text.pack(fill=tk.BOTH, expand=True)

        member = self.system.get_current_user()
        messages = self.system.get_member_messages(member.user_id)

        for msg in messages:
            text.insert(tk.END, f"{msg}\n\n")

        text.configure(state="disabled")


    # -------------------------------------
    # Search Books
    # -------------------------------------
    def search_books(self):
        popup = tk.Toplevel(self)
        popup.title("Search Books")
        popup.geometry("700x480")

        tk.Label(popup, text="Search by Title / Author / Category").pack(pady=5)

        entry = tk.Entry(popup, width=50)
        entry.pack(pady=5)
        entry.bind("<Return>", lambda event: perform_search())

        # State containers (MISSING BEFORE ❌)
        results = []
        availability = []
        last_search_term = {"value": ""}

        # Button bar (ONLY ONE ✅)
        btn_frame = tk.Frame(popup)
        btn_frame.pack(pady=5)

        search_btn = tk.Button(btn_frame, text="Search", width=15)
        search_btn.pack(side="left", padx=5)

        refresh_btn = tk.Button(btn_frame, text="Refresh", width=15)
        refresh_btn.pack(side="left", padx=5)

        listbox = tk.Listbox(popup, width=95, height=15)
        listbox.pack(pady=10)

        borrow_btn = tk.Button(
            popup,
            text="Borrow Selected Book",
            width=25,
            state=tk.DISABLED
        )
        borrow_btn.pack(pady=10)


        reserve_btn = tk.Button(
            popup,
            text="Reserve Selected Book",
            width=25,
            state=tk.DISABLED
        )   
        reserve_btn.pack(pady=5)


        def perform_search():
            listbox.delete(0, tk.END)
            results.clear()
            availability.clear()
            borrow_btn.config(state=tk.DISABLED)

            term = entry.get().lower().strip()
            last_search_term["value"] = term

            if not term:
                messagebox.showinfo("Info", "Enter a search term.")
                return

            
            for book in self.system.books:
                if (
                    term in book.title.lower()
                    or term in book.author.lower()
                    or term in book.category.lower()
                ):
                    found = True

                    # --- availability logic ---
                    total_copies = len(book.copies)
                    available_copies = 0
                    reserved_for_me = False
                    current_member = self.system.get_current_user()

                    for copy in book.copies:
                        if copy.status == "AVAILABLE":
                            available_copies += 1
                        elif copy.status == "RESERVED" and copy.reserved_for == current_member.user_id:
                            reserved_for_me = True

                    if total_copies == 0:
                        status_text = "NO COPIES ❌"
                        is_available = False
                    elif available_copies > 0:
                        status_text = f"AVAILABLE ✅ ({available_copies}/{total_copies})"
                        is_available = True
                    elif reserved_for_me:
                        status_text = "RESERVED FOR YOU ⏳"
                        is_available = True
                    else:
                        status_text = "ALL COPIES BORROWED ❌"
                        is_available = False

                    # ✅ ALWAYS show the book
                    results.append(book)
                    availability.append(is_available)

                    listbox.insert(
                        tk.END,
                        f"{book.title} | {book.author} | {book.category} | {status_text}"
                    )

            if not found:
                listbox.insert(tk.END, "No matching books found.")


        def refresh_search():
            if last_search_term["value"]:
                perform_search()

        
        def on_selection_change(event):
            if not listbox.curselection():
                borrow_btn.config(state=tk.DISABLED)
                reserve_btn.config(state=tk.DISABLED)
                return

            index = listbox.curselection()[0]

            if availability[index]:
                # Book is available → borrow allowed, reserve not allowed
                borrow_btn.config(state=tk.NORMAL)
                reserve_btn.config(state=tk.DISABLED)
            else:
                # Book is unavailable → reserve allowed, borrow not allowed
                borrow_btn.config(state=tk.DISABLED)
                reserve_btn.config(state=tk.NORMAL)


        def borrow_selected():
            index = listbox.curselection()[0]
            book = results[index]

            message = (
                "Borrow Rules:\n"
                "- Loan period: 2 weeks\n"
                "- Max books: 5\n"
                "- Fine after due date\n"
                "- Suspension after prolonged delay\n\n"
                "Do you want to continue?"
            )

            if not messagebox.askyesno("Borrow Rules", message):
                return

            member = self.system.get_current_user()
            policy = member.borrowing_policy
            fine_policy = member.fine_policy

            borrow_rules = (
                "Borrowing Rules:\n\n"
                f"- Loan period: {policy.borrowing_duration().days} days\n"
                f"- Max books allowed: {policy.max_books_allowed()}\n"
                "- Late return fine:\n"
                "  • Up to 7 days late: $1 total\n"
                "  • Beyond 7 days: $0.50 per extra day\n"
                "- Suspension rules:\n"
                "  • > 4 weeks late: limited borrowing & no reservations\n"
                "  • > 8 weeks late: account suspension\n\n"
                "Do you want to proceed?"
            )

            if not messagebox.askyesno("Borrow Rules", borrow_rules):
                return


            try:
                record = self.system.borrow_service.borrow(
                    self.system.get_current_user().user_id,
                    book.book_id
                )
                self.system.save_all()
                messagebox.showinfo(
                    "Success",
                    f"Book borrowed successfully.\n\nBorrow Record ID:\n{record.record_id}"
                )
                refresh_search()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        listbox.bind("<<ListboxSelect>>", on_selection_change)
        search_btn.config(command=perform_search)
        refresh_btn.config(command=refresh_search)
        borrow_btn.config(command=borrow_selected)
    
        
        def reserve_selected():
            index = listbox.curselection()[0]
            book = results[index]
            member = self.system.get_current_user()

            try:
                reservation = self.system.reservation_service.create_reservation(
                    member.user_id,
                    book.book_id
                )
                self.system.save_all()

                messagebox.showinfo(
                    "Reservation Created",
                    f"Reservation placed successfully.\n\nReservation ID:\n{reservation.reservation_id}"
                )
                refresh_search()

            except Exception as e:
                messagebox.showerror("Error", str(e))


        reserve_btn.config(command=reserve_selected)



    
    def view_my_reservations(self):
        popup = tk.Toplevel(self)
        popup.title("My Reservations")
        popup.geometry("700x400")

        tree = ttk.Treeview(
            popup,
            columns=("res_id", "book_id", "status"),
            show="headings"
        )
        tree.pack(fill="both", expand=True)

        tree.heading("res_id", text="Reservation ID")
        tree.heading("book_id", text="Book ID")
        tree.heading("status", text="Status")

        member = self.system.get_current_user()

        for r in self.system.reservations:
            if r.member_id == member.user_id:
                tree.insert(
                    "",
                    tk.END,
                    values=(r.reservation_id, r.book_id, r.status)
                )

        def cancel_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showerror("Error", "Please select a reservation.")
                return

            reservation_id = tree.item(selected[0], "values")[0]

            try:
                self.system.reservation_service.cancel_reservation(
                    reservation_id,
                    member.user_id
                )
                self.system.save_all()
                messagebox.showinfo("Success", "Reservation cancelled.")
                popup.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(
            popup,
            text="Cancel Reservation",
            command=cancel_selected,
            width=20
        ).pack(pady=10)

    def view_recommendations(self):
        popup = tk.Toplevel(self)
        popup.title("Recommended Books")
        popup.geometry("600x400")

        text = tk.Text(popup, wrap="word", state="normal", padx=10, pady=10)
        text.pack(fill=tk.BOTH, expand=True)

        member = self.system.get_current_user()
        books = self.system.get_recommended_books_for_member(member.user_id)

        if not books:
            text.insert(tk.END, "No recommendations available yet.\n")
        else:
            for book in books:
                text.insert(
                    tk.END,
                    f"📘 {book.title}\n"
                    f"Author: {book.author}\n"
                    f"Category: {book.category}\n"
                    + "-" * 40 + "\n\n"
                )

        text.configure(state="disabled")

    def view_borrowing_policy(self):
        member = self.system.get_current_user()

        policy = member.borrowing_policy
        fine_policy = member.fine_policy
        suspension_policy = member.suspension_policy

        popup = tk.Toplevel(self)
        popup.title("My Borrowing Policy")
        popup.geometry("520x420")
        popup.resizable(False, False)

        text_area = tk.Text(
            popup,
            wrap="word",
            state="normal",
            padx=15,
            pady=15
        )
        text_area.pack(fill=tk.BOTH, expand=True)

        policy_text = (
            "📘 My Borrowing Policy\n\n"
            f"Loan duration: {policy.borrowing_duration().days} days\n"
            f"Maximum active loans: {policy.max_books_allowed()}\n\n"

            "Late return fines:\n"
            "• Up to 7 days late: $1 total\n"
            "• After 7 days: $0.50 per additional day\n\n"

            "Suspension rules:\n"
            "• More than 28 days overdue:\n"
            "  - Borrowing limit reduced\n"
            "  - Reservations disabled\n"
            "• More than 56 days overdue:\n"
            "  - Account suspended\n\n"
        )

        if not member.active:
            policy_text += "⚠️ STATUS: Your account is currently SUSPENDED.\n\n"
        else:
            policy_text += "✅ STATUS: Your account is ACTIVE.\n\n"

        policy_text += (
            "Note:\n"
            "These rules are enforced automatically by the system\n"
            "and cannot be modified by users."
        )

        text_area.insert(tk.END, policy_text)
        text_area.configure(state="disabled")

    
    def view_my_borrow_status(self):
        popup = tk.Toplevel(self)
        popup.title("My Borrow Status")
        popup.geometry("1200x450")

        columns = (
            "record_id",
            "book_id",
            "copy_id",
            "borrow_date",
            "due_date",
            "returned",
            "status",
            "fine"
        )

        tree = ttk.Treeview(
            popup,
            columns=columns,
            show="headings"
        )

        # ---------- Column headers ----------
        tree.heading("record_id", text="Borrow ID")
        tree.heading("book_id", text="Book ID")
        tree.heading("copy_id", text="Copy ID")
        tree.heading("borrow_date", text="Borrow Date")
        tree.heading("due_date", text="Due Date")
        tree.heading("returned", text="Returned Date")
        tree.heading("status", text="Status")
        tree.heading("fine", text="Fine ($)")

        # ---------- Column widths ----------
        tree.column("record_id", width=260, anchor="w")
        tree.column("book_id", width=260, anchor="w")
        tree.column("copy_id", width=260, anchor="w")
        tree.column("borrow_date", width=160)
        tree.column("due_date", width=160)
        tree.column("returned", width=160)
        tree.column("status", width=120)
        tree.column("fine", width=80, anchor="e")

        # ---------- Scrollbars ----------
        y_scroll = ttk.Scrollbar(popup, orient="vertical", command=tree.yview)
        x_scroll = ttk.Scrollbar(popup, orient="horizontal", command=tree.xview)

        tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)

        tree.pack(fill=tk.BOTH, expand=True, side=tk.TOP)
        x_scroll.pack(fill=tk.X, side=tk.BOTTOM)
        y_scroll.pack(fill=tk.Y, side=tk.RIGHT)

        # ---------- Populate rows ----------
        member = self.system.get_current_user()

        for record in self.system.borrow_records:
            if record.member_id == member.user_id:
                book = self.system.book_service.get_book_by_copy_id(record.copy_id)

                tree.insert(
                    "",
                    tk.END,
                    values=(
                        record.record_id,
                        book.book_id,
                        record.copy_id,
                        record.borrow_date,
                        record.due_date,
                        record.return_date or "NOT RETURNED",
                        record.status,
                        f"{record.fine_amount:.2f}"
                    )
                )

    # -------------------------------------
    # Logout
    # -------------------------------------

    def logout(self):
        self.system.logout()
        self.destroy()
        self.on_logout()