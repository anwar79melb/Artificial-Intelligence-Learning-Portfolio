import tkinter as tk
from tkinter import messagebox
from tkinter import ttk


# ===============================
# UI COLOR THEME
# ===============================
BACKGROUND = "#F4F6FA"
PRIMARY = "#2C3E50"
ACCENT = "#3498DB"
BUTTON_BG = "#ECF0F1"


class StaffView(tk.Frame):

    def __init__(self, master, system, on_logout):
        super().__init__(master)
        self.system = system
        self.on_logout = on_logout
        master.configure(bg=BACKGROUND)
        self.configure(bg=BACKGROUND)
        self.pack(fill=tk.BOTH, expand=True)

        tk.Label(self, text="Staff Dashboard", font=("Arial", 18, "bold"), bg=BACKGROUND, fg=PRIMARY).pack(pady=20)

        tk.Button(self, text="Manage Books", width=30, command=self.manage_books).pack(pady=5)

        tk.Button(self, text="Manage Member", width=30, command=self.manage_members).pack(pady=5)
        
        tk.Button(self, text="Search Books", width=30, bg = BUTTON_BG, fg = PRIMARY, command=self.search_books).pack(pady=5)
        
        tk.Button(self, text="Manage Borrows", width=30, command=self.manage_borrows).pack(pady=5)

        tk.Button(self, text="Process Borrow", width=30, command=self.process_borrow).pack(pady=5)

        # tk.Button(self, text="Process Return", width=30, command=self.process_return).pack(pady=5)
        tk.Button(self, text="View Borrowing Policies", width=30, command=self.view_borrowing_policies).pack(pady=5)
        tk.Button(self, text="Create Reservation", width=30, command=self.create_reservation).pack(pady=5)

        tk.Button(self, text="View Reservation Queues", width=30, command=self.view_reservation_queues).pack(pady=5)

        tk.Button(self, text="View Overdue Items", width=30, command=self.view_overdue_items).pack(pady=5)

        tk.Button(self, text="View System Summary", width=30, command=self.view_system_summary).pack(pady=5)
        tk.Button(self, text="View System Logs", width=30, command=self.view_system_logs).pack(pady=5)

        tk.Button(self, text="Logout", width=30, command=self.logout).pack(pady=20)

    # --------------------------------------------------
    # Manage Books
    # --------------------------------------------------


    def manage_books(self):
        popup = tk.Toplevel(self)
        popup.title("Manage Books")
        popup.geometry("900x450")

        # ---------- Search ----------
        tk.Label(popup, text="Search Books").pack(pady=5)
        search_entry = tk.Entry(popup, width=40)
        search_entry.pack(pady=5)

        # ---------- Table ----------
        columns = (
            "book_id",
            "title",
            "author",
            "category",
            "total",
            "available"
        )
        tree = ttk.Treeview(popup, columns=columns, show="headings")
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for col in columns:
            tree.heading(col, text=col.replace("_", " ").title())
            tree.column(col, width=140)

        def refresh():
            tree.delete(*tree.get_children())
            keyword = search_entry.get().lower().strip()

            for book in self.system.books:
                if (
                    not keyword
                    or keyword in book.title.lower()
                    or keyword in book.author.lower()
                    or keyword in book.category.lower()
                ):
                    total = len(book.copies)
                    available = sum(
                        1 for c in book.copies if c.status == "AVAILABLE"
                    )
                    tree.insert(
                        "",
                        tk.END,
                        values=(
                            book.book_id,
                            book.title,
                            book.author,
                            book.category,
                            total,
                            available
                        )
                    )

        refresh()

        tk.Button(popup, text="Search", command=refresh).pack(pady=3)

        # ---------- Action Buttons ----------
        btn_frame = tk.Frame(popup)
        btn_frame.pack(pady=10)

        tk.Button(
            btn_frame,
            text="Add Book",
            width=18,
            command=lambda: self.add_book_popup(refresh)
        ).grid(row=0, column=0, padx=5)

        tk.Button(
            btn_frame,
            text="Add Copy",
            width=18,
            command=lambda: self.add_copy_popup(tree, refresh)
        ).grid(row=0, column=1, padx=5)

        tk.Button(
            btn_frame,
            text="Delete Copy",
            width=18,
            command=lambda: self.delete_copy_popup(tree, refresh)
        ).grid(row=0, column=2, padx=5)

        tk.Button(
            btn_frame,
            text="Delete Book",
            width=18,
            command=lambda: self.delete_book_popup(tree, refresh)
        ).grid(row=0, column=3, padx=5)



    def add_book_popup(self, refresh):
        popup = tk.Toplevel(self)
        popup.title("Add Book")
        popup.geometry("350x300")

        fields = {}
        for label in ("Title", "Author", "Category", "ISBN"):
            tk.Label(popup, text=label).pack()
            entry = tk.Entry(popup, width=35)
            entry.pack()
            fields[label] = entry

        def submit():
            try:
                self.system.book_service.add_book(
                    fields["Title"].get(),
                    fields["Author"].get(),
                    fields["Category"].get(),
                    fields["ISBN"].get()
                )
                self.system.save_all()
                refresh()
                popup.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Add Book", command=submit).pack(pady=10)



    def add_copy_popup(self, tree, refresh):
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select a book.")
            return

        book_id = tree.item(selected[0], "values")[0]

        try:
            self.system.book_service.add_copy(book_id)
            self.system.save_all()
            refresh()
        except Exception as e:
            messagebox.showerror("Error", str(e))



    def delete_copy_popup(self, tree, refresh):
        popup = tk.Toplevel(self)
        popup.title("Delete Book Copy")

        tk.Label(popup, text="Book Copy ID").pack(pady=5)
        entry = tk.Entry(popup, width=40)
        entry.pack(pady=5)

        def submit():
            try:
                self.system.book_service.remove_copy(entry.get().strip())
                self.system.save_all()
                refresh()
                popup.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Delete Copy", command=submit).pack(pady=10)



    def delete_book_popup(self, tree, refresh):
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select a book.")
            return

        book_id = tree.item(selected[0], "values")[0]

        confirm = messagebox.askyesno(
            "Confirm",
            "Delete this book?\nThis cannot be undone."
        )
        if not confirm:
            return

        try:
            self.system.book_service.delete_book(
                book_id,
                self.system.borrow_records
            )
            self.system.save_all()
            refresh()
        except Exception as e:
            messagebox.showerror("Error", str(e))



    def add_book(self):
        popup = tk.Toplevel(self)
        popup.title("Add Book")
        popup.geometry("300x300")

        labels = ["Title", "Author", "Category", "ISBN"]
        entries = {}

        for label in labels:
            tk.Label(popup, text=label).pack()
            entry = tk.Entry(popup)
            entry.pack()
            entries[label] = entry

        def submit():
            try:
                title = entries["Title"].get()
                author = entries["Author"].get()
                category = entries["Category"].get()
                isbn = entries["ISBN"].get()

                self.system.book_service.add_book(
                    title, author, category, isbn
                )
                self.system.save_all()

                messagebox.showinfo("Success", "Book added successfully.")
                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Submit", command=submit).pack(pady=15)

    # --------------------------------------------------
    # Add Book Copy
    # --------------------------------------------------

    def add_copy(self):
        popup = tk.Toplevel(self)
        popup.title("Add Book Copy")

        tk.Label(popup, text="Book ID").pack()
        entry = tk.Entry(popup)
        entry.pack()

        def submit():
            try:
                book_id = entry.get()
                self.system.book_service.add_copy(book_id)
                self.system.save_all()
                messagebox.showinfo("Success", "Book copy added.")
                popup.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Submit", command=submit).pack(pady=10)


    def delete_copy(self):
        popup = tk.Toplevel(self)
        popup.title("Delete Book Copy")
        popup.geometry("350x200")
        popup.resizable(False, False)

        tk.Label(popup, text="Book Copy ID").place(x=20, y=20)
        copy_entry = tk.Entry(popup, width=40)
        copy_entry.place(x=20, y=45)

        def submit():
            try:
                copy_id = copy_entry.get().strip()

                if not copy_id:
                    messagebox.showerror("Error", "Copy ID is required.")
                    return

                self.system.book_service.remove_copy(copy_id)
                self.system.save_all()

                messagebox.showinfo("Success", "Book copy deleted successfully.")
                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(
            popup,
            text="Delete Copy",
            width=20,
            command=submit
        ).place(x=85, y=110)


    def delete_book(self):
        popup = tk.Toplevel(self)
        popup.title("Delete Book")

        tk.Label(popup, text="Book ID").pack()
        entry = tk.Entry(popup, width=40)
        entry.pack(pady=5)

        def submit():
            try:
                self.system.book_service.delete_book(
                    entry.get().strip(),
                    self.system.borrow_records
                )
                self.system.save_all()
                messagebox.showinfo("Deleted", "Book deleted successfully.")
                popup.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Delete", command=submit).pack(pady=10)



    def search_books(self):
        popup = tk.Toplevel(self)
        popup.title("Search Books")
        popup.geometry("900x500")

        tk.Label(popup, text="Search by Title / Author / Category").pack(pady=5)

        entry = tk.Entry(popup, width=50)
        entry.pack(pady=5)
        entry.bind("<Return>", lambda event: perform_search())

        # Scrollable result area
        text_frame = tk.Frame(popup)
        text_frame.pack(fill="both", expand=True, padx=10, pady=10)

        output = tk.Text(text_frame, wrap="none")
        output.pack(side="left", fill="both", expand=True)

        scrollbar_y = tk.Scrollbar(text_frame, orient="vertical", command=output.yview)
        scrollbar_y.pack(side="right", fill="y")
        output.configure(yscrollcommand=scrollbar_y.set)

        last_search_term = {"value": ""}

        def perform_search():
            output.delete("1.0", tk.END)

            term = entry.get().lower().strip()
            last_search_term["value"] = term

            if not term:
                output.insert(tk.END, "Please enter a search term.\n")
                return

            found = False
            for book in self.system.books:
                if (
                    term in book.title.lower()
                    or term in book.author.lower()
                    or term in book.category.lower()
                ):
                    found = True
                    
                    
                    
                    total_copies = len(book.copies)
                    available_copies = sum(
                        1 for copy in book.copies if copy.status == "AVAILABLE"
                    )
                    reserved_copies = sum(
                        1 for copy in book.copies if copy.status == "RESERVED"
                    )

                    if total_copies == 0:
                        status_text = "NO COPIES ❌"
                    elif available_copies > 0:
                        status_text = f"AVAILABLE ✅ ({available_copies}/{total_copies})"
                    elif reserved_copies > 0:
                        status_text = f"RESERVED ⏳ ({reserved_copies}/{total_copies})"
                    else:
                        status_text = "ALL COPIES BORROWED ❌"




                    
                    output.insert(
                        tk.END,
                        f"BOOK ID: {book.book_id}\n"
                        f"Title: {book.title}\n"
                        f"Author: {book.author}\n"
                        f"Category: {book.category}\n"
                        f"Copies: {available_copies + reserved_copies}/{total_copies}\n"
                        f"Status: {status_text}\n"
                        + "-" * 80 + "\n"
                    )


            if not found:
                output.insert(tk.END, "No matching books found.\n")

        def refresh_search():
            if last_search_term["value"]:
                perform_search()

        # Button bar
        btn_frame = tk.Frame(popup)
        btn_frame.pack(pady=5)

        tk.Button(
            btn_frame,
            text="Search",
            width=15,
            command=perform_search
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame,
            text="Refresh",
            width=15,
            command=refresh_search
        ).pack(side="left", padx=5)

    def _build_borrow_table(self, parent):
        columns = (
            "record_id",
            "member_id",
            "copy_id",
            "borrow_date",
            "due_date",
            "returned",
            "status",
            "fine"
        )

        tree = ttk.Treeview(
            parent,
            columns=columns,
            show="headings"
        )

        tree.heading("record_id", text="Borrow ID")
        tree.heading("member_id", text="Member ID")
        tree.heading("copy_id", text="Copy ID")
        tree.heading("borrow_date", text="Borrow Date")
        tree.heading("due_date", text="Due Date")
        tree.heading("returned", text="Returned Date")
        tree.heading("status", text="Status")
        tree.heading("fine", text="Fine ($)")

        tree.column("record_id", width=220)
        tree.column("member_id", width=200)
        tree.column("copy_id", width=200)
        tree.column("borrow_date", width=140)
        tree.column("due_date", width=140)
        tree.column("returned", width=160)
        tree.column("status", width=100)
        tree.column("fine", width=90, anchor="e")

        # Scrollbars
        y_scroll = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        x_scroll = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
        tree.configure(
            yscrollcommand=y_scroll.set,
            xscrollcommand=x_scroll.set
        )

        tree.pack(fill=tk.BOTH, expand=True, side=tk.TOP)
        x_scroll.pack(fill=tk.X, side=tk.BOTTOM)
        y_scroll.pack(fill=tk.Y, side=tk.RIGHT)

        self.borrow_tree = tree
        self.refresh_borrow_table()

    def manage_borrows(self):
        popup = tk.Toplevel(self)
        popup.title("Manage Borrows")
        popup.geometry("1200x500")

        # 1️⃣ Borrow Records Table 
        self._build_borrow_table(popup)

        # 2️⃣ Action Buttons
        btn_frame = tk.Frame(popup)
        btn_frame.pack(pady=8)

        tk.Button(
            btn_frame,
            text="Process Borrow",
            width=18,
            command=self.process_borrow
        ).grid(row=0, column=0, padx=5)

        tk.Button(
            btn_frame,
            text="Process Return",
            width=18,
            command=lambda: self.process_return_from_table()
        ).grid(row=0, column=1, padx=5)

        tk.Button(
            btn_frame,
            text="Refresh",
            width=18,
            command=lambda: self.refresh_borrow_table()
        ).grid(row=0, column=2, padx=5)


    def refresh_borrow_table(self):
        self.borrow_tree.delete(*self.borrow_tree.get_children())

        for record in self.system.borrow_records:
            self.borrow_tree.insert(
                "",
                tk.END,
                values=(
                    record.record_id,
                    record.member_id,
                    record.copy_id,
                    record.borrow_date,
                    record.due_date,
                    record.return_date or "NOT RETURNED",
                    record.status,
                    f"{record.fine_amount:.2f}"
                )
            )


    def process_return_from_table(self):
        selected = self.borrow_tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select a borrow record.")
            return

        record_id = self.borrow_tree.item(selected[0], "values")[0]
        self.process_return_with_id(record_id)


    def view_borrow_records(self):
        popup = tk.Toplevel(self)
        popup.title("Borrow Records")
        popup.geometry("1200x450")

        columns = (
            "record_id",
            "member_id",
            "copy_id",
            "borrow_date",
            "due_date",
            "returned",
            "status",
            "fine"
        )

        tree = ttk.Treeview(
            popup,
            columns=columns,
            show="headings"
        )

        # Define headings
        tree.heading("record_id", text="Borrow ID")
        tree.heading("member_id", text="Member ID")
        tree.heading("copy_id", text="Copy ID")
        tree.heading("borrow_date", text="Borrow Date")
        tree.heading("due_date", text="Due Date")
        tree.heading("returned", text="Returned Date")
        tree.heading("status", text="Status")
        tree.heading("fine", text="Fine ($)")

        # Column widths (adjust as needed)
        tree.column("record_id", width=260, anchor="w")
        tree.column("member_id", width=260, anchor="w")
        tree.column("copy_id", width=260, anchor="w")
        tree.column("borrow_date", width=160)
        tree.column("due_date", width=160)
        tree.column("returned", width=160)
        tree.column("status", width=100)
        tree.column("fine", width=80, anchor="e")

        # Scrollbars
        y_scroll = ttk.Scrollbar(popup, orient="vertical", command=tree.yview)
        x_scroll = ttk.Scrollbar(popup, orient="horizontal", command=tree.xview)

        tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)

        tree.pack(fill=tk.BOTH, expand=True, side=tk.TOP)
        x_scroll.pack(fill=tk.X, side=tk.BOTTOM)
        y_scroll.pack(fill=tk.Y, side=tk.RIGHT)

        # Populate data
        for record in self.system.borrow_records:
            tree.insert(
                "",
                tk.END,
                values=(
                    record.record_id,
                    record.member_id,
                    record.copy_id,
                    record.borrow_date,
                    record.due_date,
                    record.return_date or "NOT RETURNED",
                    record.status,
                    f"{record.fine_amount:.2f}"
                )
            )

        
        def copy_selected_borrow_id():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("No Selection", "Please select a borrow record.")
                return

            borrow_id = tree.item(selected[0], "values")[0]  # Borrow ID = first column
            popup.clipboard_clear()
            popup.clipboard_append(borrow_id)

            messagebox.showinfo("Copied", f"Borrow ID copied to clipboard:\n\n{borrow_id}")

        
        copy_btn = tk.Button(
            popup,
            text="Copy Borrow ID",
            command=copy_selected_borrow_id,
            width=20
        )
        copy_btn.pack(pady=8)

    def process_borrow(self):
        popup = tk.Toplevel(self)
        popup.title("Process Borrow")
        popup.geometry("700x400")

        # -------- Members --------
        tk.Label(popup, text="Select Member").pack(pady=5)

        members = [
            m for m in self.system.members
            if m.get_role() != "Staff"
        ]

        member_var = tk.StringVar()
        member_map = {}

        member_list = []
        for m in members:
            label = f"{m.username} ({m.full_name})"
            member_map[label] = m.user_id
            member_list.append(label)

        member_menu = tk.OptionMenu(popup, member_var, *member_list)
        member_menu.pack()
        member_var.set(member_list[0])

        # -------- Books --------
        tk.Label(popup, text="Select Book").pack(pady=10)

        book_var = tk.StringVar()
        book_map = {}

        book_list = []
        for b in self.system.books:
            label = f"{b.title} ({b.book_id})"
            book_map[label] = b.book_id
            book_list.append(label)

        book_menu = tk.OptionMenu(popup, book_var, *book_list)
        book_menu.pack()
        book_var.set(book_list[0])

        # -------- Submit --------
        def submit():
            try:
                member_id = member_map[member_var.get()]
                book_id = book_map[book_var.get()]

                record = self.system.borrow_service.borrow(
                    member_id,
                    book_id
                )
                self.system.save_all()

                messagebox.showinfo(
                    "Borrow Processed",
                    f"Borrow ID:\n{record.record_id}"
                )
                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Process Borrow", command=submit).pack(pady=20)

        
    def process_return(self):
        popup = tk.Toplevel(self)
        popup.title("Process Return")
        popup.geometry("420x260")
        popup.resizable(False, False)

        tk.Label(popup, text="Borrow Record ID").place(x=20, y=20)
        record_entry = tk.Entry(popup, width=45)
        record_entry.place(x=20, y=45)

        tk.Label(popup, text="Return Condition").place(x=20, y=85)
        condition_var = tk.StringVar(value="GOOD")
        tk.OptionMenu(popup, condition_var, "GOOD", "DAMAGED", "LOST").place(x=20, y=110)

        def submit():
            try:
                record_id = record_entry.get().strip()
                condition = condition_var.get()

                if not record_id:
                    messagebox.showerror("Error", "Borrow Record ID is required.")
                    return

                record = self.system.borrow_service.return_book(record_id, condition)
                self.system.save_all()

                messagebox.showinfo(
                    "Return Processed",
                    f"Book returned successfully.\nFine: ${record.fine_amount:.2f}"
                )
                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        # ✅ THIS WILL ALWAYS BE VISIBLE
        tk.Button(
            popup,
            text="Process Return",
            width=20,
            command=submit
        ).place(x=120, y=190)



    def manage_members(self):
        popup = tk.Toplevel(self)
        popup.title("Manage Members")
        popup.geometry("800x450")

        # --- Search ---
        tk.Label(popup, text="Search Member").pack(pady=5)
        search_entry = tk.Entry(popup, width=40)
        search_entry.pack(pady=5)

        # --- Member Table ---
        columns = ("id", "username", "name", "role", "active")
        tree = ttk.Treeview(popup, columns=columns, show="headings")
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for col in columns:
            tree.heading(col, text=col.capitalize())
            tree.column(col, width=140)

        def refresh():
            tree.delete(*tree.get_children())
            keyword = search_entry.get().lower().strip()

            for m in self.system.members:
                if (
                    keyword in m.username.lower()
                    or keyword in m.full_name.lower()
                    or not keyword
                ):
                    tree.insert("", tk.END, values=(
                        m.user_id,
                        m.username,
                        m.full_name,
                        m.get_role(),
                        "Active" if m.active else "Inactive"
                    ))

        refresh()

        
        tk.Button(popup, text="Search", command=refresh).pack(pady=3)

        # ---------- Button Frame ----------
        btn_frame = tk.Frame(popup)
        btn_frame.pack(pady=10)

        tk.Button(
            btn_frame,
            text="Add Member",
            width=18,
            command=lambda: self.add_member_popup(refresh)
        ).grid(row=0, column=0, padx=5)

        tk.Button(
            btn_frame,
            text="Edit Selected",
            width=18,
            command=lambda: self.edit_member_popup(tree, refresh)
        ).grid(row=0, column=1, padx=5)

        tk.Button(
            btn_frame,
            text="Delete Selected",
            width=18,
            command=lambda: self.delete_selected_member(tree, refresh)
        ).grid(row=0, column=2, padx=5)




    def add_member_popup(self, refresh):
        popup = tk.Toplevel(self)
        popup.title("Add Member")

        # username, name, password, role
        # On submit -> member_service.create_member(...)
        # self.system.save_all()
        # refresh()



    def edit_member_popup(self, tree, refresh):
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a member.")
            return

        member_id = tree.item(selected[0], "values")[0]
        member = self.system.member_service.get_member_by_id(member_id)

        popup = tk.Toplevel(self)
        popup.title("Edit Member")
        popup.geometry("400x350")
        popup.resizable(False, False)

        # ---------- Username ----------
        tk.Label(popup, text="Username").pack(pady=5)
        username_entry = tk.Entry(popup, width=35)
        username_entry.insert(0, member.username)
        username_entry.pack()

        # ---------- Full Name ----------
        tk.Label(popup, text="Full Name").pack(pady=5)
        name_entry = tk.Entry(popup, width=35)
        name_entry.insert(0, member.full_name)
        name_entry.pack()

        # ---------- Role ----------
        tk.Label(popup, text="Role").pack(pady=5)
        role_var = tk.StringVar(value=member.get_role())
        role_menu = tk.OptionMenu(
            popup,
            role_var,
            "Member",
            "Parent",
            "Child",
            "Staff"
        )
        role_menu.pack()

        # ---------- Active status ----------
        active_var = tk.BooleanVar(value=member.active)
        tk.Checkbutton(
            popup,
            text="Active Account",
            variable=active_var
        ).pack(pady=10)

        # ---------- Save ----------
        def save_changes():
            member.username = username_entry.get().strip()
            member.full_name = name_entry.get().strip()
            member.active = active_var.get()

            new_role = role_var.get()
            self.system.member_service.set_role(member, new_role)

            self.system.save_all()
            refresh()
            popup.destroy()

        tk.Button(
            popup,
            text="Save Changes",
            width=20,
            command=save_changes
        ).pack(pady=15)


    def delete_selected_member(self, tree, refresh):
        selected = tree.selection()
        if not selected:
            return

        member_id = tree.item(selected[0], "values")[0]

        try:
            self.system.member_service.delete_member(
                member_id,
                self.system.borrow_records,
                self.system.reservations
            )
            self.system.save_all()
            refresh()
            messagebox.showinfo("Deleted", "Member removed.")
        except Exception as e:
            messagebox.showerror("Error", str(e))


    def add_member(self):
        popup = tk.Toplevel(self)
        popup.title("Add Member")
        popup.geometry("300x300")

        tk.Label(popup, text="Username").pack()
        username_entry = tk.Entry(popup)
        username_entry.pack()

        tk.Label(popup, text="Full Name").pack()
        fullname_entry = tk.Entry(popup)
        fullname_entry.pack()

        tk.Label(popup, text="Password").pack()
        password_entry = tk.Entry(popup, show="*")
        password_entry.pack()

        tk.Label(popup, text="Member Type").pack()
        member_type_var = tk.StringVar(value="general")
        tk.OptionMenu(
            popup,
            member_type_var,
            "general", "child", "parent"
        ).pack()

        def submit():
            try:
                username = username_entry.get()
                full_name = fullname_entry.get()
                password = password_entry.get()
                member_type = member_type_var.get()

                if not username or not password or not full_name:
                    messagebox.showerror("Error", "All fields are required.")
                    return

                self.system.member_service.create_member(
                    member_type,
                    username,
                    password,
                    full_name
                )
                self.system.save_all()
                messagebox.showinfo("Success", "Member created successfully.")
                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(popup, text="Create Member", command=submit).pack(pady=15)


    
    def delete_member(self):
        popup = tk.Toplevel(self)
        popup.title("Delete Member")
        popup.geometry("700x400")

        tk.Label(popup, text="Search Member (Username or Name)").pack(pady=5)
        search_entry = tk.Entry(popup, width=40)
        search_entry.pack(pady=5)

        columns = ("member_id", "username", "full_name", "role")
        tree = ttk.Treeview(popup, columns=columns, show="headings")
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        tree.heading("member_id", text="Member ID")
        tree.heading("username", text="Username")
        tree.heading("full_name", text="Full Name")
        tree.heading("role", text="Role")

        tree.column("member_id", width=220)
        tree.column("username", width=120)
        tree.column("full_name", width=200)
        tree.column("role", width=120)

        def refresh_list():
            tree.delete(*tree.get_children())
            keyword = search_entry.get().lower().strip()

            for member in self.system.members:
                if (
                    keyword in member.username.lower()
                    or keyword in member.full_name.lower()
                    or not keyword
                ):
                    tree.insert(
                        "",
                        tk.END,
                        values=(
                            member.user_id,
                            member.username,
                            member.full_name,
                            member.get_role()
                        )
                    )

        refresh_list()

        tk.Button(
            popup,
            text="Search",
            command=refresh_list
        ).pack(pady=5)

        def delete_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showerror("Error", "Please select a member.")
                return

            member_id = tree.item(selected[0], "values")[0]

            confirm = messagebox.askyesno(
                "Confirm Deletion",
                "Are you sure you want to delete this member?\n\n"
                "This action cannot be undone."
            )
            if not confirm:
                return

            try:
                self.system.member_service.delete_member(
                    member_id,
                    self.system.borrow_records,
                    self.system.reservations
                )
                self.system.save_all()
                messagebox.showinfo("Success", "Member deleted successfully.")
                popup.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(
            popup,
            text="Delete Selected Member",
            width=25,
            command=delete_selected
        ).pack(pady=10)



    def view_overdue_items(self):
        popup = tk.Toplevel(self)
        popup.title("Overdue Items")
        popup.geometry("900x400")

        columns = (
            "record_id",
            "member",
            "book",
            "due_date",
            "days_overdue"
        )

        tree = ttk.Treeview(popup, columns=columns, show="headings")
        tree.pack(fill=tk.BOTH, expand=True)

        for col in columns:
            tree.heading(col, text=col.replace("_", " ").title())
            tree.column(col, width=180)

        from datetime import datetime
        now = datetime.now()

        overdue_records = self.system.get_overdue_items()

        for r in overdue_records:
            days = (now - r.due_date).days
            member = self.system.member_service.get_member_by_id(r.member_id)
            book = self.system.book_service.get_book_by_copy_id(r.copy_id)

            tree.insert(
                "",
                tk.END,
                values=(
                    r.record_id,
                    member.username,
                    book.title,
                    r.due_date.strftime("%Y-%m-%d"),
                    days
                )
            )

        if not overdue_records:
            messagebox.showinfo("Overdue Items", "No overdue items found.")
            popup.destroy()


    def view_reservation_queues(self):
        popup = tk.Toplevel(self)
        popup.title("Reservation Queues")
        popup.geometry("900x400")

        tk.Label(popup, text="Select Book").pack(pady=5)

        book_map = {}
        book_titles = []

        for b in self.system.books:
            label = f"{b.title} ({b.book_id})"
            book_map[label] = b.book_id
            book_titles.append(label)

        book_var = tk.StringVar(value=book_titles[0])
        tk.OptionMenu(popup, book_var, *book_titles).pack()

        columns = ("order", "reservation_id", "member", "status")

        tree = ttk.Treeview(popup, columns=columns, show="headings")
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for col in columns:
            tree.heading(col, text=col.replace("_", " ").title())
            tree.column(col, width=200)

        def load_queue():
            tree.delete(*tree.get_children())
            book_id = book_map[book_var.get()]
            reservations = self.system.reservation_service.get_active_reservations_by_book(book_id)

            for idx, r in enumerate(reservations, start=1):
                member = self.system.member_service.get_member_by_id(r.member_id)
                tree.insert(
                    "",
                    tk.END,
                    values=(idx, r.reservation_id, member.username, r.status)
                )

            if not reservations:
                messagebox.showinfo("Reservation Queue", "No active reservations for this book.")

        tk.Button(popup, text="Load Queue", command=load_queue).pack(pady=5)


    
    def view_system_summary(self):
        summary = self.system.get_system_summary()

        messagebox.showinfo(
            "System Summary",
            f"Total Titles: {summary['titles']}\n"
            f"Total Copies: {summary['copies']}\n"
            f"Available Copies: {summary['available']}\n"
            f"Borrowed Copies: {summary['borrowed']}\n"
            f"Reserved Items: {summary['reserved']}"
        )




    def view_borrowing_policies(self):
        from policies.borrowing_policy import (
            GeneralBorrowingPolicy,
            ParentBorrowingPolicy,
            ChildBorrowingPolicy,
            StaffBorrowingPolicy
        )
        from policies.fine_policy import (
            GeneralFinePolicy,
            ParentFinePolicy,
            ChildFinePolicy,
            StaffFinePolicy
        )

        popup = tk.Toplevel(self)
        popup.title("System Borrowing Policies")
        popup.geometry("600x520")
        popup.resizable(False, False)

        text = tk.Text(popup, wrap="word", padx=15, pady=15)
        text.pack(fill=tk.BOTH, expand=True)

        policies_text = (
            "📘 SYSTEM BORROWING POLICIES (READ‑ONLY)\n\n"

            "🧑 General Member\n"
            f"- Loan duration: {GeneralBorrowingPolicy().borrowing_duration().days} days\n"
            f"- Max books: {GeneralBorrowingPolicy().max_books_allowed()}\n"
            "- Late fine: $1 per day\n\n"

            "👨 Parent Member\n"
            f"- Loan duration: {ParentBorrowingPolicy().borrowing_duration().days} days\n"
            f"- Max books: {ParentBorrowingPolicy().max_books_allowed()}\n"
            "- Late fine: $0.50 per day\n\n"

            "🧒 Child Member\n"
            f"- Loan duration: {ChildBorrowingPolicy().borrowing_duration().days} days\n"
            f"- Max books: {ChildBorrowingPolicy().max_books_allowed()}\n"
            "- Late fine: $0.20 per day\n"
            "- Reservations: Not allowed\n\n"

            "🧑‍💼 Staff\n"
            f"- Loan duration: {StaffBorrowingPolicy().borrowing_duration().days} days\n"
            f"- Max books: {StaffBorrowingPolicy().max_books_allowed()}\n"
            "- Late fine: $5 per week\n"
            "- No automatic suspension\n\n"

            "Suspension Rules (Members Only)\n"
            "- > 28 days overdue: limited borrowing, no reservations\n"
            "- > 56 days overdue: account suspended\n\n"

            "Note:\nPolicies are enforced automatically by the system\n"
            "and cannot be modified from the interface."
        )

        text.insert(tk.END, policies_text)
        text.configure(state="disabled")


    def create_reservation(self):
        popup = tk.Toplevel(self)
        popup.title("Create Reservation")
        popup.geometry("520x360")
        popup.resizable(False, False)

        # ==================================================
        # Member dropdown
        # ==================================================
        tk.Label(popup, text="Select Member").pack(pady=(10, 2))

        member_map = {}
        member_display_list = []

        for user in self.system.members:
            if user.get_role().startswith("Member"):
                display = f"{user.username} ({user.get_role()})"
                member_map[display] = user.user_id
                member_display_list.append(display)

        if not member_display_list:
            tk.Label(
                popup,
                text="No members available for reservation.",
                fg="red"
            ).pack(pady=10)
            return

        selected_member = tk.StringVar(value=member_display_list[0])

        tk.OptionMenu(
            popup,
            selected_member,
            *member_display_list
        ).pack(pady=5)

        # ==================================================
        # Book dropdown (UNAVAILABLE books only)
        # ==================================================
        tk.Label(popup, text="Select Book (Unavailable Only)").pack(pady=(15, 2))

        book_map = {}
        book_display_list = []

        for book in self.system.books:
            # Only books with copies AND none available
            if book.copies and not self.system.book_service.is_book_available(book.book_id):
                display = f"{book.title} | {book.author} (ID: {book.book_id})"
                book_map[display] = book.book_id
                book_display_list.append(display)

        if not book_display_list:
            tk.Label(
                popup,
                text="No unavailable books to reserve.",
                fg="green"
            ).pack(pady=10)
            return

        selected_book = tk.StringVar(value=book_display_list[0])

        tk.OptionMenu(
            popup,
            selected_book,
            *book_display_list
        ).pack(pady=5)

        # ==================================================
        # Submit reservation
        # ==================================================
        def submit():
            try:
                member_display = selected_member.get()
                book_display = selected_book.get()

                member_id = member_map[member_display]
                book_id = book_map[book_display]

                reservation = self.system.reservation_service.create_reservation(
                    member_id,
                    book_id
                )
                self.system.save_all()

                messagebox.showinfo(
                    "Reservation Created",
                    f"Reservation created successfully.\n\n"
                    f"Member: {member_display}\n"
                    f"Book: {book_display}\n\n"
                    f"Reservation ID:\n{reservation.reservation_id}"
                )
                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(
            popup,
            text="Create Reservation",
            width=30,
            command=submit
        ).pack(pady=20)

    
    def view_system_logs(self):
        popup = tk.Toplevel(self)
        popup.title("System Logs")
        popup.geometry("900x500")

        text_frame = tk.Frame(popup)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        text_area = tk.Text(
            text_frame,
            wrap="none",
            state="normal"
        )
        text_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(
            text_frame,
            orient=tk.VERTICAL,
            command=text_area.yview
        )
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        text_area.configure(yscrollcommand=scrollbar.set)

        try:
            with open("logs/system.log", "r", encoding="utf-8") as f:
                content = f.read()
                text_area.insert(tk.END, content)
        except FileNotFoundError:
            text_area.insert(
                tk.END,
                "Log file not found.\nNo system events have been recorded yet."
            )

        # Make logs read-only
        text_area.configure(state="disabled")

    # --------------------------------------------------
    # Logout
    # --------------------------------------------------

    def logout(self):
        self.system.logout()
        self.destroy()
        self.on_logout()