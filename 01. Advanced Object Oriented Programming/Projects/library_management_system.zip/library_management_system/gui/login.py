


import tkinter as tk
from tkinter import messagebox
from utils.exceptions import AuthenticationError


# ===============================
# UI COLOR THEME
# ===============================
BACKGROUND = "#F4F6FA"
PRIMARY = "#2C3E50"
BUTTON_BG = "#ECF0F1"


class LoginView(tk.Frame):
    def __init__(self, master, system, on_success):
        super().__init__(master)

        self.system = system
        self.on_success = on_success

        # ✅ for changing background color
        master.configure(bg=BACKGROUND)
        self.configure(bg=BACKGROUND)

        self.pack(fill=tk.BOTH, expand=True)

        tk.Label(
            self,
            text="Library Management System",
            font=("Arial", 18, "bold"),
            bg=BACKGROUND,
            fg=PRIMARY
        ).pack(pady=20)

        tk.Label(self, text="Username", bg=BACKGROUND, fg=PRIMARY).pack()
        self.username_entry = tk.Entry(self)
        self.username_entry.pack()

        tk.Label(self, text="Password", bg=BACKGROUND, fg=PRIMARY).pack()
        self.password_entry = tk.Entry(self, show="*")
        self.password_entry.pack()

        tk.Button(
            self,
            text="Login",
            bg=BUTTON_BG,
            fg=PRIMARY,
            command=self.login
        ).pack(pady=10)

    def login(self):
        try:
            self.system.login(
                self.username_entry.get(),
                self.password_entry.get()
            )
            self.on_success()
        except AuthenticationError as e:
            messagebox.showerror("Login Failed", str(e))
