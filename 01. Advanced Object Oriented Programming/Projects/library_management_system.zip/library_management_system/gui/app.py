
import tkinter as tk
from core.library_system import LibrarySystem
from gui.login import LoginView


class LibraryApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Library Management System")
        self.geometry("800x600")

        #self.root = root
        # Central system instance
        self.system = LibrarySystem()

        # Load login screen
        self.show_login()

    def show_login(self):
        self.clear_window()
        LoginView(self, self.system, self.show_dashboard)

    
    def show_dashboard(self):
        self.clear_window()

        user = self.system.get_current_user()

        # ✅ Staff dashboard
        if self.system.is_staff():
            from gui.staff_view import StaffView
            StaffView(self, self.system, self.show_login)

        # ✅ Member dashboard
        else:
            from gui.member_view import MemberView
            MemberView(self, self.system, self.show_login)


    def clear_window(self):
        for widget in self.winfo_children():
            widget.destroy()


if __name__ == "__main__":
    app = LibraryApp()
    app.mainloop()

