import os
import pickle
import csv


class FileManager:

    def load(self, filename):
        """
        Safely load data from a .dat file.
        Returns an empty list if the file does not exist or is corrupted.
        """
        if not os.path.exists(filename):
            return []

        try:
            with open(filename, "rb") as f:
                return pickle.load(f)
        except (EOFError, pickle.UnpicklingError):
            return []

    def save(self, filename, data):
        """
        Save data safely to a .dat file.
        """
        with open(filename, "wb") as f:
            pickle.dump(data, f)

    # --------------------------------------------------
    # CSV EXPORT HELPERS (READ‑ONLY)
    # --------------------------------------------------

    def export_books_to_csv(self, books, filename="Books.csv"):
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["Book ID", "Title", "Author", "Category", "Copy ID", "Copy Status"]
            )

            for book in books:
                for copy in book.copies:
                    writer.writerow([
                        book.book_id,
                        book.title,
                        book.author,
                        book.category,
                        copy.copy_id,
                        copy.status
                    ])

    def export_borrows_to_csv(self, borrows, filename="Borrows.csv"):
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["Record ID", "Member ID", "Copy ID", "Borrow Date",
                 "Due Date", "Return Date", "Status", "Fine"]
            )

            for record in borrows:
                writer.writerow([
                    record.record_id,
                    record.member_id,
                    record.copy_id,
                    record.borrow_date,
                    record.due_date,
                    record.return_date,
                    record.status,
                    record.fine_amount
                ])


    
    
    def export_reservations_to_csv(self, reservations):
        with open("Reservations.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "Reservation ID",
                "Book ID",
                "Member ID",
                "Copy ID",
                "Status",
                "Reserved At",
                "Expires At"
            ])
            for r in reservations:
                writer.writerow([
                    r.reservation_id,
                    r.book_id,
                    r.member_id,
                    r.copy_id,
                    r.status,
                    r.reserved_at,
                    r.expires_at
                ])



    def export_members_to_csv(self, members, filename="Members.csv"):
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["User ID", "Username", "Full Name", "Role", "Active"]
            )

            for member in members:
                writer.writerow([
                    member.user_id,
                    member.username,
                    member.full_name,
                    member.get_role(),
                    member.active
                ])
