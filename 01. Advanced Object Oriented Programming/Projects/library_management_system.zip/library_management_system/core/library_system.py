from utils.logger import log_event
from core.file_manager import FileManager
from services.borrow_service import BorrowService
from services.book_service import BookService
from services.member_service import MemberService
from services.reservation_service import ReservationService
from datetime import datetime


from utils.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ValidationError
)
from utils.hashing import verify_password


class LibrarySystem:
    """
    Central facade for the Library Management System.

    This class owns:
    - Persistent storage
    - In‑memory collections
    - Service wiring
    - Authentication state

    GUI and CLI layers should interact ONLY with this class.
    """

    def __init__(self):
        # ------------------------
        # Persistence layer
        # ------------------------
        self.file_manager = FileManager()

        # ------------------------
        # Load persistent state
        # ------------------------
        self.books = self.file_manager.load("Books.dat")
        self.members = self.file_manager.load("Members.dat")
        from policies.suspension_policy import SuspensionPolicy
        for user in self.members:
            # ✅ Migration for older pickled users
            if not hasattr(user, "suspension_policy"):
                user.suspension_policy = SuspensionPolicy()

        self.borrow_records = self.file_manager.load("Borrows.dat")
        self.reservations = self.file_manager.load("Reservations.dat")

        
        # ✅ MIGRATION: ensure all BookCopy objects have reservation fields
        for book in self.books:
            for copy in book.copies:
                if not hasattr(copy, "reserved_for"):
                    copy.reserved_for = None
                if not hasattr(copy, "reserved_until"):
                    copy.reserved_until = None

        
        for book in self.books:
            for copy in book.copies:
                if copy.status not in ("AVAILABLE", "BORROWED", "DAMAGED", "LOST"):
                    copy.status = "AVAILABLE"


        # ------------------------
        # Wire services
        # ------------------------
        self.book_service = BookService(self.books)

        self.member_service = MemberService(
            self.members,
            self.borrow_records
        )

        self.reservation_service = ReservationService(
            self.reservations,
            self.book_service,
            self.member_service
        )

        self.borrow_service = BorrowService(
            self.borrow_records,
            self.book_service,
            self.member_service,
            self.reservation_service
        )
        
        # ------------------------
        # Bootstrap admin user
        # ------------------------
        if not self.members:
            from models.user import Staff
            from utils.hashing import hash_password
            
            admin = Staff(
                user_id="admin-001",
                username="admin",
                password_hash=hash_password("admin123"),
                full_name="System Administrator",
                role="Manager"
            )
            self.members.append(admin)
            
            log_event(
                "System bootstrap: default admin account created (username=admin)"
            )

            self.save_all()


        # ------------------------
        # Session state
        # ------------------------
        self.current_user = None

    # ======================================================
    # Authentication & session
    # ======================================================

    def login(self, username: str, password: str):
        """
        Authenticate a user and set the current session.
        """
        for user in self.members:
            if user.username == username:
                if not user.active:
                    raise AuthenticationError("Account is inactive.")

                if verify_password(password, user.password_hash):
                    self.current_user = user
                    log_event(f"User login: username={user.username}, role={user.get_role()}")

                    return

                raise AuthenticationError("Invalid password.")

        raise AuthenticationError("User not found.")
    
    
    def logout(self):
        if self.current_user is not None:
            log_event(
                f"User logout: username={self.current_user.username}, user_id={self.current_user.user_id}"
            )
        self.current_user = None


    def require_login(self):
        if self.current_user is None:
            raise AuthorizationError("Login required.")

    # ======================================================
    # Role helpers
    # ======================================================

    def get_current_user(self):
        self.require_login()
        return self.current_user

    def is_staff(self) -> bool:
        self.require_login()
        return self.current_user.get_role().startswith("Staff")

    def is_member(self) -> bool:
        self.require_login()
        return self.current_user.get_role().startswith("Member")



    def get_member_messages(self, member_id):
        messages = []
        now = datetime.now()

        # ---------- Overdue notices ----------
        for record in self.borrow_records:
            if record.member_id == member_id and record.status == "ACTIVE":
                if record.due_date < now:
                    days_overdue = (now - record.due_date).days
                    book = self.book_service.get_book_by_copy_id(record.copy_id)

                    messages.append(
                        f"🔴 OVERDUE: '{book.title}' is overdue by {days_overdue} day(s)."
                    )

        # ---------- Reservation status ----------
        for r in self.reservations:
            if r.member_id == member_id:
                book = self.book_service.get_book_by_id(r.book_id)

                if r.status == "ACTIVE":
                    messages.append(
                        f"🟡 RESERVATION ACTIVE: '{book.title}' is reserved for you."
                    )
                elif r.status == "WAITING":
                    messages.append(
                        f"🟡 RESERVATION READY: '{book.title}' is available for pickup."
                    )
                elif r.status == "FULFILLED":
                    messages.append(
                        f"🟢 RESERVATION FULFILLED: You have borrowed '{book.title}'."
                    )
                elif r.status == "CANCELLED":
                    messages.append(
                        f"⚪ RESERVATION CANCELLED: '{book.title}'."
                    )

        if not messages:
            messages.append("✅ No new account messages.")

        return messages


    def get_overdue_items(self):
        now = datetime.now()
        overdue = []

        for record in self.borrow_records:
            if record.status == "ACTIVE" and record.due_date < now:
                overdue.append(record)

        return overdue


    def get_system_summary(self):
        total_titles = len(self.books)
        total_copies = sum(len(b.copies) for b in self.books)

        available = sum(
            1 for b in self.books
            for c in b.copies if c.status == "AVAILABLE"
        )

        borrowed = sum(1 for r in self.borrow_records if r.status == "ACTIVE")
        reserved = sum(1 for r in self.reservations if r.status == "ACTIVE")

        return {
            "titles": total_titles,
            "copies": total_copies,
            "available": available,
            "borrowed": borrowed,
            "reserved": reserved
        }



    def get_recommended_books_for_member(self, member_id, limit=5):
        # Step 1: get borrow history
        borrowed_book_ids = set()
        category_count = {}

        for record in self.borrow_records:
            if record.member_id == member_id:
                book = self.book_service.get_book_by_copy_id(record.copy_id)
                borrowed_book_ids.add(book.book_id)
                category_count[book.category] = category_count.get(book.category, 0) + 1

        
        if not category_count:
            # Fallback: recommend any available books
            return [
                book for book in self.books
                if any(c.status == "AVAILABLE" for c in book.copies)
            ][:limit]


        # Step 2: sort categories by frequency
        sorted_categories = sorted(
            category_count,
            key=category_count.get,
            reverse=True
        )

        # Step 3: recommend books from those categories
        recommendations = []
        for category in sorted_categories:
            for book in self.books:
                if (
                    book.category == category
                    and book.book_id not in borrowed_book_ids
                    and any(c.status == "AVAILABLE" for c in book.copies)
                ):
                    recommendations.append(book)
                    if len(recommendations) >= limit:
                        return recommendations

        return recommendations


    # ======================================================
    # Persistence coordination
    # ======================================================
    
    def save_all(self):
        self.file_manager.save("Books.dat", self.books)
        self.file_manager.save("Members.dat", self.members)
        self.file_manager.save("Borrows.dat", self.borrow_records)
        self.file_manager.save("Reservations.dat", self.reservations)

        # Read‑only CSV mirrors
        self.file_manager.export_books_to_csv(self.books)
        self.file_manager.export_borrows_to_csv(self.borrow_records)
        self.file_manager.export_members_to_csv(self.members)


    # ======================================================
    # Safe shutdown
    # ======================================================

    def shutdown(self):
        """
        Save data and clear session safely.
        """
        log_event("System shutdown initiated.")
        self.save_all()
        self.logout()