# Package initializer

class LibrarySystem:
    """
    Central facade for the Library Management System.
    """

    def __init__(self):
        # Persistence
        self.file_manager = FileManager()

        # Load persistent state
        self.books = self.file_manager.load("Books.dat")
        self.members = self.file_manager.load("Members.dat")
        self.borrow_records = self.file_manager.load("Borrows.dat")
        self.reservations = self.file_manager.load("Reservations.dat")

        # Current session user
        self.current_user = None

        # ------------------------
        # Service wiring
        # ------------------------

        self.book_service = BookService(self.books)

        self.member_service = MemberService(
            self.members,
            self.borrow_records
        )

        self.reservation_service = ReservationService(
            self.reservations,
            self.book_service,
            self.member_service
        )

        self.borrow_service = BorrowService(
            self.borrow_records,
            self.book_service,
            self.member_service,
            self.reservation_service
        )

        

